"""
Email utilities — IMAP connection, fetching, moving, archiving.
Works with Gmail (App Password) and most IMAP providers.
"""

import asyncio
import email
import imaplib
import json
from datetime import datetime
from email.header import decode_header
from typing import Optional


def _decode_header_value(value: str) -> str:
    """Decode email header (handles encoded words like =?UTF-8?...)"""
    if not value:
        return ""
    parts = decode_header(value)
    decoded = []
    for part, enc in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(enc or "utf-8", errors="replace"))
        else:
            decoded.append(str(part))
    return " ".join(decoded)


class EmailManager:
    def __init__(self, config: dict):
        self.config = config
        self.imap_config = config.get("imap", {})
        self.email_config = config.get("email", {})

    def _connect(self) -> imaplib.IMAP4_SSL:
        """Create and return an authenticated IMAP connection."""
        conn = imaplib.IMAP4_SSL(
            self.imap_config["host"],
            self.imap_config.get("port", 993)
        )
        conn.login(self.imap_config["user"], self.imap_config["password"])
        return conn

    async def fetch_inbox(self, limit: int = 20) -> list:
        """Fetch recent unprocessed inbox emails."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._fetch_inbox_sync, limit)

    def _fetch_inbox_sync(self, limit: int) -> list:
        emails = []
        try:
            conn = self._connect()
            conn.select("INBOX")
            
            # Search for unseen emails
            _, message_ids = conn.search(None, "UNSEEN")
            ids = message_ids[0].split()
            ids = ids[-limit:]  # Most recent
            
            for uid in ids:
                _, msg_data = conn.fetch(uid, "(RFC822)")
                if not msg_data or not msg_data[0]:
                    continue
                
                raw = msg_data[0][1]
                msg = email.message_from_bytes(raw)
                
                subject = _decode_header_value(msg.get("Subject", ""))
                sender = _decode_header_value(msg.get("From", ""))
                date_str = msg.get("Date", "")
                
                # Get snippet from body
                snippet = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            snippet = part.get_payload(decode=True).decode("utf-8", errors="replace")[:300]
                            break
                else:
                    payload = msg.get_payload(decode=True)
                    if payload:
                        snippet = payload.decode("utf-8", errors="replace")[:300]
                
                emails.append({
                    "uid": uid.decode(),
                    "subject": subject,
                    "sender": sender,
                    "snippet": snippet.strip(),
                    "date": date_str
                })
            
            conn.logout()
        except Exception as e:
            print(f"IMAP error: {e}")
        
        return emails

    async def execute_action(self, uid: str, decision: dict):
        """Execute an email action (move, archive, delete, label)."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._execute_action_sync, uid, decision)

    def _execute_action_sync(self, uid: str, decision: dict):
        action = decision.get("action", "archive")
        category = decision.get("category", "Other")
        
        try:
            conn = self._connect()
            conn.select("INBOX")
            
            if action == "move" or action == "label":
                target_folder = category
                # Create folder if it doesn't exist
                conn.create(target_folder)
                conn.copy(uid, target_folder)
                conn.store(uid, "+FLAGS", "\\Deleted")
                conn.expunge()
            
            elif action == "archive":
                archive_folder = self.email_config.get("archive_label", "[Gmail]/All Mail")
                conn.copy(uid, archive_folder)
                conn.store(uid, "+FLAGS", "\\Deleted")
                conn.expunge()
            
            elif action == "delete":
                conn.store(uid, "+FLAGS", "\\Deleted")
                conn.expunge()
            
            conn.logout()
        except Exception as e:
            print(f"Email action error for uid {uid}: {e}")
            raise

    async def undo_action(self, action: dict):
        """Attempt to undo a previous action (move back to INBOX)."""
        uid = action.get("item_id", "")
        category = action.get("category", "")
        
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._undo_sync, uid, category)

    def _undo_sync(self, uid: str, category: str):
        try:
            conn = self._connect()
            conn.select(category)
            conn.copy(uid, "INBOX")
            conn.store(uid, "+FLAGS", "\\Deleted")
            conn.expunge()
            conn.logout()
        except Exception as e:
            print(f"Undo error: {e}")
            raise
