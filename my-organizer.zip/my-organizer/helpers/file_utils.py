"""
File utilities — watch folders, move, rename PDFs and documents.
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional


WATCHED_EXTENSIONS = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".png", ".jpg", ".jpeg"}

SKIP_PATTERNS = [
    ".DS_Store", "Thumbs.db", ".tmp", ".log", ".crdownload", ".part",
    "desktop.ini", ".localized"
]


class FileManager:
    def __init__(self, config: dict):
        self.config = config
        self.watch_folders = [
            Path(p).expanduser()
            for p in config.get("folders", {}).get("watch", [])
        ]
        self.organize_root = Path(
            config.get("folders", {}).get("organize_root", "~/Organized")
        ).expanduser()
        self.categories = config.get("folders", {}).get("categories", ["Other"])

    def scan_watched_folders(self) -> list:
        """Return all organizable files in watched folders."""
        files = []
        for folder in self.watch_folders:
            if not folder.exists():
                continue
            for path in folder.iterdir():
                if not path.is_file():
                    continue
                if path.name in SKIP_PATTERNS:
                    continue
                if path.suffix.lower() not in WATCHED_EXTENSIONS:
                    continue
                
                files.append({
                    "path": str(path),
                    "name": path.name,
                    "extension": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat()
                })
        return files

    def execute_action(self, file_path: str, decision: dict):
        """Execute a file action (move, rename_and_move, skip)."""
        action = decision.get("action", "skip")
        category = decision.get("category", "Other")
        new_name = decision.get("new_name")
        
        if action == "skip":
            return
        
        src = Path(file_path)
        if not src.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        dest_folder = self.organize_root / category
        dest_folder.mkdir(parents=True, exist_ok=True)
        
        if action == "rename_and_move" and new_name:
            dest = dest_folder / new_name
        else:
            dest = dest_folder / src.name
        
        # Handle name conflicts
        if dest.exists():
            stem = dest.stem
            suffix = dest.suffix
            i = 1
            while dest.exists():
                dest = dest_folder / f"{stem}_{i}{suffix}"
                i += 1
        
        shutil.move(str(src), str(dest))
        decision["final_path"] = str(dest)

    async def undo_action(self, action: dict):
        """Move a file back to its original location."""
        original_path = action.get("item_id", "")
        final_path = action.get("final_path", "")
        
        if not final_path or not Path(final_path).exists():
            raise FileNotFoundError(f"File no longer at {final_path}")
        
        dest = Path(original_path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(final_path, str(dest))

    def ensure_category_folders(self):
        """Create all category folders under organize_root."""
        for cat in self.categories:
            folder = self.organize_root / cat
            folder.mkdir(parents=True, exist_ok=True)
        print(f"✅ Created category folders under {self.organize_root}")
