"""
Database layer — SQLite via SQLAlchemy.
Stores all actions, corrections, and stats.
"""

import json
import os
import time
from datetime import datetime, date
from typing import Optional


class Database:
    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "storage", "actions.db"
            )
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init_db()

    def _get_conn(self):
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS actions (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_type   TEXT NOT NULL,          -- 'email' | 'file'
                    item_id     TEXT NOT NULL,           -- email UID or file path
                    subject     TEXT,
                    sender      TEXT,
                    snippet     TEXT,
                    filename    TEXT,
                    extension   TEXT,
                    category    TEXT,
                    action      TEXT,
                    new_name    TEXT,
                    confidence  REAL DEFAULT 0,
                    used_model  TEXT DEFAULT 'free_api',
                    reasoning   TEXT,
                    undone      INTEGER DEFAULT 0,
                    needs_confirmation INTEGER DEFAULT 0,
                    created_at  REAL DEFAULT (unixepoch())
                );

                CREATE TABLE IF NOT EXISTS corrections (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    action_id       INTEGER REFERENCES actions(id),
                    correct_category TEXT,
                    correct_action  TEXT,
                    notes           TEXT,
                    created_at      REAL DEFAULT (unixepoch())
                );

                CREATE INDEX IF NOT EXISTS idx_actions_created ON actions(created_at);
                CREATE INDEX IF NOT EXISTS idx_actions_category ON actions(category);
                CREATE INDEX IF NOT EXISTS idx_actions_sender ON actions(sender);
                CREATE INDEX IF NOT EXISTS idx_corrections_action ON corrections(action_id);
            """)

    def log_action(self, item_type: str, item_id: str, decision: dict) -> int:
        with self._get_conn() as conn:
            cur = conn.execute("""
                INSERT INTO actions
                    (item_type, item_id, subject, sender, snippet, filename, extension,
                     category, action, new_name, confidence, used_model, reasoning,
                     needs_confirmation)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                item_type, item_id,
                decision.get("subject"), decision.get("sender"),
                decision.get("snippet"), decision.get("filename"),
                decision.get("extension"), decision.get("category"),
                decision.get("action"), decision.get("new_name"),
                decision.get("confidence", 0), decision.get("used_model", "free_api"),
                decision.get("reasoning"), int(decision.get("needs_confirmation", False))
            ))
            return cur.lastrowid

    def get_action(self, action_id: int) -> Optional[dict]:
        with self._get_conn() as conn:
            row = conn.execute("SELECT * FROM actions WHERE id=?", (action_id,)).fetchone()
            return dict(row) if row else None

    def get_actions(self, limit: int = 50, offset: int = 0) -> list:
        with self._get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM actions ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset)
            ).fetchall()
            return [dict(r) for r in rows]

    def count_actions(self) -> int:
        with self._get_conn() as conn:
            return conn.execute("SELECT COUNT(*) FROM actions").fetchone()[0]

    def mark_undone(self, action_id: int):
        with self._get_conn() as conn:
            conn.execute("UPDATE actions SET undone=1 WHERE id=?", (action_id,))

    def log_correction(self, action_id: int, correct_category: str,
                       correct_action: str, notes: str = None):
        with self._get_conn() as conn:
            conn.execute("""
                INSERT INTO corrections (action_id, correct_category, correct_action, notes)
                VALUES (?,?,?,?)
            """, (action_id, correct_category, correct_action, notes))

    def count_corrections(self) -> int:
        with self._get_conn() as conn:
            return conn.execute("SELECT COUNT(*) FROM corrections").fetchone()[0]

    def get_correction_stats(self) -> dict:
        with self._get_conn() as conn:
            total = conn.execute("SELECT COUNT(*) FROM corrections").fetchone()[0]
            by_cat = conn.execute("""
                SELECT correct_category, COUNT(*) as count
                FROM corrections GROUP BY correct_category ORDER BY count DESC
            """).fetchall()
            return {
                "total_corrections": total,
                "by_category": [dict(r) for r in by_cat],
                "training_ready": total >= 50
            }

    def get_baby_ai_accuracy(self) -> Optional[float]:
        """Calculate Baby AI accuracy from corrections."""
        with self._get_conn() as conn:
            total_baby = conn.execute(
                "SELECT COUNT(*) FROM actions WHERE used_model='baby_ai'"
            ).fetchone()[0]
            if total_baby == 0:
                return None
            corrected_baby = conn.execute("""
                SELECT COUNT(*) FROM corrections c
                JOIN actions a ON c.action_id = a.id
                WHERE a.used_model = 'baby_ai'
            """).fetchone()[0]
            return round((1 - corrected_baby / total_baby) * 100, 1) if total_baby > 0 else None

    def count_api_calls_today(self) -> int:
        today_start = datetime.now().replace(hour=0, minute=0, second=0).timestamp()
        with self._get_conn() as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM actions WHERE used_model='free_api' AND created_at >= ?",
                (today_start,)
            ).fetchone()[0]

    def get_model_breakdown(self) -> dict:
        with self._get_conn() as conn:
            rows = conn.execute("""
                SELECT used_model, COUNT(*) as count
                FROM actions GROUP BY used_model
            """).fetchall()
            return {r["used_model"]: r["count"] for r in rows}

    def get_top_categories(self) -> list:
        with self._get_conn() as conn:
            rows = conn.execute("""
                SELECT category, COUNT(*) as count
                FROM actions GROUP BY category ORDER BY count DESC LIMIT 5
            """).fetchall()
            return [dict(r) for r in rows]

    def count_similar_past_actions(self, category: str, sender: str = "") -> int:
        with self._get_conn() as conn:
            if sender:
                return conn.execute(
                    "SELECT COUNT(*) FROM actions WHERE category=? AND sender LIKE ?",
                    (category, f"%{sender.split('@')[-1]}%")
                ).fetchone()[0]
            return conn.execute(
                "SELECT COUNT(*) FROM actions WHERE category=?", (category,)
            ).fetchone()[0]
