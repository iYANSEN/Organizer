/**
 * Electron Main Process
 * Creates the widget window and manages the Python backend process.
 */

const { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');

let mainWindow = null;
let tray = null;
let pythonProcess = null;

// ── Config ────────────────────────────────────────────────────────────────────

function loadConfig() {
  const configPath = path.join(__dirname, '..', 'config.json');
  const examplePath = path.join(__dirname, '..', 'config.example.json');
  
  if (!fs.existsSync(configPath)) {
    if (fs.existsSync(examplePath)) {
      fs.copyFileSync(examplePath, configPath);
      console.log('Created config.json from template');
    }
  }
  
  try {
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  } catch (e) {
    console.error('Config error:', e);
    return {};
  }
}

// ── Python Backend ─────────────────────────────────────────────────────────────

function startPythonBackend() {
  const apiPath = path.join(__dirname, '..', 'api', 'server.py');
  
  pythonProcess = spawn('python', ['-m', 'uvicorn', 'api.server:app', '--port', '5000', '--no-access-log'], {
    cwd: path.join(__dirname, '..'),
    stdio: ['ignore', 'pipe', 'pipe']
  });
  
  pythonProcess.stdout.on('data', (data) => {
    console.log('[Python]', data.toString().trim());
  });
  
  pythonProcess.stderr.on('data', (data) => {
    const msg = data.toString().trim();
    if (!msg.includes('INFO')) {
      console.error('[Python Error]', msg);
    }
  });
  
  pythonProcess.on('exit', (code) => {
    console.log(`Python process exited with code ${code}`);
  });
  
  // Give the server a moment to start
  return new Promise(resolve => setTimeout(resolve, 2000));
}

// ── Window ────────────────────────────────────────────────────────────────────

function createWindow() {
  const { width, height } = require('electron').screen.getPrimaryDisplay().workAreaSize;
  
  mainWindow = new BrowserWindow({
    width: 420,
    height: 700,
    x: width - 440,
    y: 20,
    frame: false,
    transparent: true,
    alwaysOnTop: false,
    resizable: true,
    minWidth: 360,
    minHeight: 500,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    vibrancy: 'under-window',
    visualEffectState: 'active',
    roundedCorners: true,
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  
  // Restore position
  const Store = require('electron-store');
  const store = new Store();
  const savedBounds = store.get('windowBounds');
  if (savedBounds) mainWindow.setBounds(savedBounds);
  
  mainWindow.on('moved', () => store.set('windowBounds', mainWindow.getBounds()));
  mainWindow.on('resized', () => store.set('windowBounds', mainWindow.getBounds()));
  mainWindow.on('closed', () => { mainWindow = null; });
}

// ── Tray ──────────────────────────────────────────────────────────────────────

function createTray() {
  const iconPath = path.join(__dirname, '..', 'assets', 'tray-icon.png');
  const icon = fs.existsSync(iconPath)
    ? nativeImage.createFromPath(iconPath).resize({ width: 16 })
    : nativeImage.createEmpty();
  
  tray = new Tray(icon);
  tray.setToolTip('My Organizer');
  
  const menu = Menu.buildFromTemplate([
    { label: 'Show Widget', click: () => mainWindow?.show() },
    { label: 'Hide Widget', click: () => mainWindow?.hide() },
    { type: 'separator' },
    { label: 'Open Organized Folder', click: () => {
      const config = loadConfig();
      const folder = config.folders?.organize_root?.replace('~', require('os').homedir());
      if (folder) shell.openPath(folder);
    }},
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]);
  
  tray.setContextMenu(menu);
  tray.on('click', () => {
    if (mainWindow?.isVisible()) {
      mainWindow.hide();
    } else {
      mainWindow?.show();
      mainWindow?.focus();
    }
  });
}

// ── IPC Handlers ──────────────────────────────────────────────────────────────

ipcMain.handle('get-config', () => loadConfig());

ipcMain.handle('open-folder', (_, folderPath) => {
  shell.openPath(folderPath.replace('~', require('os').homedir()));
});

ipcMain.handle('minimize-window', () => mainWindow?.minimize());
ipcMain.handle('close-window', () => mainWindow?.hide());

// ── App Lifecycle ─────────────────────────────────────────────────────────────

app.whenReady().then(async () => {
  await startPythonBackend();
  createWindow();
  createTray();
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  // Keep running in tray on macOS
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  if (pythonProcess) pythonProcess.kill();
});
