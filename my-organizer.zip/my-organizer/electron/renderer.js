/**
 * Renderer — UI logic for My Organizer widget.
 * Communicates with the Python backend via REST API.
 */

const API = 'http://127.0.0.1:5000';
const CATEGORIES = [
  'Finances', 'Work', 'Personal', 'Receipts',
  'Travel', 'Health', 'Legal', 'Newsletters', 'Other'
];

let selectedCategory = null;
let activeActionId = null;
let activeTab = 'activity';

// ── Init ───────────────────────────────────────────────────────────────────────

window.addEventListener('DOMContentLoaded', async () => {
  buildCategoryGrid();
  await checkHealth();
  loadActivity();
  setInterval(checkHealth, 30000);
  setInterval(() => { if (activeTab === 'activity') loadActivity(); }, 60000);
});

// ── Health Check ───────────────────────────────────────────────────────────────

async function checkHealth() {
  const dot = document.getElementById('status-dot');
  const text = document.getElementById('status-text');
  const pill = document.getElementById('model-pill');
  
  try {
    const data = await api('/health');
    dot.classList.remove('offline');
    text.textContent = 'Connected · API ready';
    
    if (data.baby_ai) {
      pill.textContent = 'BABY AI';
      pill.className = 'status-pill pill-baby';
    } else {
      pill.textContent = 'FREE API';
      pill.className = 'status-pill pill-api';
    }
  } catch (e) {
    dot.classList.add('offline');
    text.textContent = 'Backend offline — start the server';
  }
}

// ── Tab Navigation ─────────────────────────────────────────────────────────────

function switchTab(tab) {
  activeTab = tab;
  document.querySelectorAll('.tab-btn').forEach((btn, i) => {
    btn.classList.toggle('active', ['activity','queue','stats','train'][i] === tab);
  });
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.getElementById(`tab-${tab}`).classList.add('active');
  
  if (tab === 'activity') loadActivity();
  else if (tab === 'queue') loadQueue();
  else if (tab === 'stats') loadStats();
  else if (tab === 'train') loadTrain();
}

// ── Activity ───────────────────────────────────────────────────────────────────

async function loadActivity() {
  const list = document.getElementById('activity-list');
  list.innerHTML = '<div class="loader"><div class="spinner"></div></div>';
  
  try {
    const data = await api('/actions?limit=30');
    if (!data.actions || data.actions.length === 0) {
      list.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📭</div>
          <div class="empty-text">No actions yet.<br>Click ⚡ All to start organizing.</div>
        </div>`;
      return;
    }
    
    list.innerHTML = data.actions.map(a => renderActionCard(a)).join('');
  } catch (e) {
    list.innerHTML = `<div class="empty-state"><div class="empty-text">Cannot load actions.<br>Is the backend running?</div></div>`;
  }
}

function renderActionCard(action) {
  const conf = action.confidence || 0;
  const confColor = conf >= 80 ? 'badge-green' : conf >= 50 ? 'badge-amber' : 'badge-red';
  const modelLabel = action.used_model === 'baby_ai' ? '🤖 Baby AI' : '🌐 Free API';
  const isEmail = action.item_type === 'email';
  const title = isEmail ? (action.subject || 'No subject') : (action.filename || action.item_id.split('/').pop());
  const subtitle = isEmail ? (action.sender || '') : action.action;
  const undone = action.undone ? ' style="opacity:0.4"' : '';
  
  return `
  <div class="action-card"${undone} id="card-${action.id}">
    <div class="card-type">${isEmail ? '✉ Email' : '📄 File'} · ${timeAgo(action.created_at)}</div>
    <div class="card-subject" title="${title}">${title}</div>
    <div class="card-meta">${subtitle}</div>
    <div class="card-footer">
      <span class="badge badge-cat">${action.category || 'Other'}</span>
      <span class="badge ${confColor}">${conf.toFixed(0)}%</span>
      <span class="badge badge-model">${modelLabel}</span>
      <div class="confidence-bar">
        <div class="confidence-fill" style="width:${conf}%"></div>
      </div>
    </div>
    ${action.undone ? '' : `
    <div class="card-actions">
      <button class="btn-sm undo" onclick="undoAction(${action.id})">Undo</button>
      <button class="btn-sm wrong" onclick="openCorrection(${action.id}, '${esc(title)}', '${action.category}')">Wrong</button>
      <button class="btn-sm why" onclick="openWhy(${action.id})">Why?</button>
    </div>`}
  </div>`;
}

// ── Queue (needs confirmation) ─────────────────────────────────────────────────

async function loadQueue() {
  const list = document.getElementById('queue-list');
  list.innerHTML = '<div class="loader"><div class="spinner"></div></div>';
  
  try {
    const data = await api('/actions?limit=50');
    const queue = (data.actions || []).filter(a => a.needs_confirmation && !a.undone);
    
    if (queue.length === 0) {
      list.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">✓</div>
          <div class="empty-text">Nothing waiting for confirmation.<br>Baby AI is handling everything!</div>
        </div>`;
      return;
    }
    
    list.innerHTML = queue.map(a => renderQueueCard(a)).join('');
  } catch (e) {
    list.innerHTML = `<div class="empty-state"><div class="empty-text">Error loading queue</div></div>`;
  }
}

function renderQueueCard(action) {
  const title = action.item_type === 'email' ? (action.subject || 'No subject') : (action.filename || '');
  return `
  <div class="action-card" id="qcard-${action.id}">
    <div class="card-type">⏳ Needs your OK · ${timeAgo(action.created_at)}</div>
    <div class="card-subject">${title}</div>
    <div class="card-meta">${action.sender || action.item_id}</div>
    <div class="card-footer">
      <span class="badge badge-cat">${action.category}</span>
      <span class="badge badge-amber">${(action.confidence||0).toFixed(0)}%</span>
      <span class="badge badge-model">🤖 Baby AI</span>
    </div>
    <div class="card-actions">
      <button class="btn-sm confirm" onclick="confirmAction(${action.id})">✓ Yes</button>
      <button class="btn-sm wrong" onclick="openCorrection(${action.id}, '${esc(title)}', '${action.category}')">✗ Wrong</button>
    </div>
  </div>`;
}

async function confirmAction(actionId) {
  showToast('✓ Action confirmed');
  document.getElementById(`qcard-${actionId}`)?.remove();
}

// ── Stats ──────────────────────────────────────────────────────────────────────

async function loadStats() {
  const el = document.getElementById('stats-content');
  el.innerHTML = '<div class="loader"><div class="spinner"></div></div>';
  
  try {
    const s = await api('/stats');
    const babyPct = s.model_used_breakdown?.baby_ai && s.total_organized
      ? Math.round(s.model_used_breakdown.baby_ai / s.total_organized * 100) : 0;
    const apiPct = 100 - babyPct;
    const accuracy = s.baby_ai_accuracy ? `${s.baby_ai_accuracy}%` : 'N/A';
    
    el.innerHTML = `
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-value accent">${s.total_organized || 0}</div>
          <div class="stat-label">Organized</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${s.total_corrections || 0}</div>
          <div class="stat-label">Corrections</div>
        </div>
        <div class="stat-card">
          <div class="stat-value green">${accuracy}</div>
          <div class="stat-label">Baby AI Acc.</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${s.free_api_calls_today || 0}</div>
          <div class="stat-label">API Calls Today</div>
        </div>
      </div>
      
      <div class="section-header">
        <span class="section-title">Model Usage</span>
      </div>
      
      <div class="model-bar">
        <div class="model-bar-header">
          <span class="model-name">🤖 Baby AI</span>
          <span class="model-pct">${babyPct}%</span>
        </div>
        <div class="model-track">
          <div class="model-fill" style="width:${babyPct}%"></div>
        </div>
      </div>
      <div class="model-bar">
        <div class="model-bar-header">
          <span class="model-name">🌐 Free API (Gemini)</span>
          <span class="model-pct">${apiPct}%</span>
        </div>
        <div class="model-track">
          <div class="model-fill" style="width:${apiPct}%;background:linear-gradient(90deg,var(--cyan),var(--green))"></div>
        </div>
      </div>
      
      <div class="section-header" style="margin-top:14px">
        <span class="section-title">Top Categories</span>
      </div>
      <div class="cat-list">
        ${(s.top_categories || []).map(c => `
          <div class="cat-row">
            <span class="cat-name">${c.category || 'Other'}</span>
            <span class="cat-count">${c.count}</span>
          </div>
        `).join('')}
      </div>`;
  } catch (e) {
    el.innerHTML = `<div class="empty-state"><div class="empty-text">Cannot load stats</div></div>`;
  }
}

// ── Train ──────────────────────────────────────────────────────────────────────

async function loadTrain() {
  const el = document.getElementById('train-content');
  el.innerHTML = '<div class="loader"><div class="spinner"></div></div>';
  
  try {
    const stats = await api('/corrections/stats');
    const total = stats.total_corrections || 0;
    const nextMilestone = total < 50 ? 50 : total < 100 ? 100 : total < 200 ? 200 : 500;
    const progress = Math.min((total / nextMilestone) * 100, 100);
    
    const phase = total < 50 ? 1 : total < 200 ? 2 : 3;
    const phaseInfo = {
      1: { icon: '🌐', title: 'Phase 1 — Free API', desc: 'Collect corrections to train Baby AI. Keep using the app and click "Wrong" when the AI makes a mistake.' },
      2: { icon: '🏋️', title: 'Phase 2 — Ready to Train', desc: 'You have enough corrections! Run the training script to create Baby AI, then unlock local inference.' },
      3: { icon: '🤖', title: 'Phase 3 — Baby AI Active', desc: 'Your local model is handling most tasks. Free API only used for unknowns. Re-train weekly for best accuracy.' },
    }[phase];
    
    el.innerHTML = `
      <div class="phase-card">
        <div class="phase-header">
          <span class="phase-icon">${phaseInfo.icon}</span>
          <span class="phase-title">${phaseInfo.title}</span>
        </div>
        <div class="phase-desc">${phaseInfo.desc}</div>
        <div class="phase-progress-track">
          <div class="phase-progress-fill" style="width:${progress}%"></div>
        </div>
        <div class="phase-milestone">
          <span>${total} corrections</span>
          <span>Next milestone: ${nextMilestone}</span>
        </div>
      </div>
      
      ${phase >= 2 ? `
      <div class="section-header">
        <span class="section-title">Training Steps</span>
      </div>
      <div class="action-card" style="animation:none">
        <div class="card-type">Terminal Command</div>
        <div class="card-subject" style="font-family:var(--mono);font-size:11px;white-space:normal">python ai/baby_ai/train.py</div>
        <div class="card-meta">Run from project root. Takes ~10 min on CPU, ~2 min on GPU.</div>
      </div>
      <div class="action-card" style="animation:none">
        <div class="card-type">After Training</div>
        <div class="card-subject" style="white-space:normal;font-size:11px">Set "baby_ai_enabled": true in config.json and restart the app.</div>
      </div>` : ''}
      
      <div class="section-header" style="margin-top:14px">
        <span class="section-title">By Category</span>
      </div>
      <div class="cat-list">
        ${(stats.by_category || []).map(c => `
          <div class="cat-row">
            <span class="cat-name">${c.correct_category}</span>
            <span class="cat-count">${c.count} corrections</span>
          </div>
        `).join('') || '<div class="empty-state" style="padding:16px"><div class="empty-text">No corrections yet</div></div>'}
      </div>`;
  } catch (e) {
    el.innerHTML = `<div class="empty-state"><div class="empty-text">Cannot load training info</div></div>`;
  }
}

// ── Actions ────────────────────────────────────────────────────────────────────

async function undoAction(actionId) {
  try {
    await api(`/actions/${actionId}/undo`, 'POST');
    showToast('↩ Action undone');
    const card = document.getElementById(`card-${actionId}`);
    if (card) card.style.opacity = '0.4';
    setTimeout(loadActivity, 500);
  } catch (e) {
    showToast('⚠ Could not undo action');
  }
}

async function organizeEmails() {
  showToast('📧 Organizing emails...');
  await api('/emails/organize-all', 'POST');
  setTimeout(loadActivity, 3000);
}

async function organizeFiles() {
  showToast('📁 Organizing files...');
  await api('/files/organize-all', 'POST');
  setTimeout(loadActivity, 3000);
}

async function organizeAll() {
  showToast('⚡ Organizing everything...');
  await Promise.all([
    api('/emails/organize-all', 'POST'),
    api('/files/organize-all', 'POST')
  ]);
  setTimeout(loadActivity, 3000);
}

// ── Correction Modal ───────────────────────────────────────────────────────────

function buildCategoryGrid() {
  document.getElementById('cat-grid').innerHTML = CATEGORIES.map(cat => `
    <button class="cat-btn" onclick="selectCategory('${cat}')">${cat}</button>
  `).join('');
}

function openCorrection(actionId, title, currentCat) {
  activeActionId = actionId;
  selectedCategory = currentCat;
  document.getElementById('modal-subtitle').textContent = `"${title.substring(0, 40)}"`;
  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.classList.toggle('selected', btn.textContent === currentCat);
  });
  document.getElementById('modal-overlay').classList.add('show');
}

function selectCategory(cat) {
  selectedCategory = cat;
  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.classList.toggle('selected', btn.textContent === cat);
  });
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('show');
  activeActionId = null;
  selectedCategory = null;
}

async function submitCorrection() {
  if (!selectedCategory || !activeActionId) return;
  
  try {
    const result = await api('/corrections', 'POST', {
      action_id: activeActionId,
      correct_category: selectedCategory,
      correct_action: 'move'
    });
    
    closeModal();
    showToast(`✓ Correction saved (${result.correction_count} total)`);
    
    if (result.correction_count % 50 === 0) {
      setTimeout(() => showToast(`🎉 ${result.correction_count} corrections — time to train Baby AI!`), 2000);
    }
    
    loadActivity();
  } catch (e) {
    showToast('⚠ Could not save correction');
  }
}

// ── Why Modal ──────────────────────────────────────────────────────────────────

async function openWhy(actionId) {
  const overlay = document.getElementById('why-overlay');
  overlay.style.display = 'flex';
  document.getElementById('why-content').textContent = 'Loading...';
  
  try {
    const data = await api(`/actions/${actionId}/why`, 'POST');
    document.getElementById('why-content').textContent = data.explanation;
  } catch (e) {
    document.getElementById('why-content').textContent = 'Could not load explanation.';
  }
}

function closeWhyModal() {
  document.getElementById('why-overlay').style.display = 'none';
}

// ── Utils ──────────────────────────────────────────────────────────────────────

async function api(path, method = 'GET', body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' }
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${API}${path}`, opts);
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}

function showToast(message) {
  const t = document.getElementById('toast');
  t.textContent = message;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 3000);
}

function timeAgo(ts) {
  if (!ts) return '';
  const diff = Date.now() / 1000 - ts;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function esc(s) {
  return (s || '').replace(/'/g, "\\'").replace(/"/g, '\\"');
}
