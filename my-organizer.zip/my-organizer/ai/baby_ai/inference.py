"""
Baby AI — Local fine-tuned model for classification.
Phase 1: Simple keyword/pattern classifier (no GPU needed)
Phase 2: LoRA fine-tuned model (uncomment torch imports when ready)

The class interface stays the same across phases so orchestrator.py
doesn't need to change.
"""

import json
import os
import re
from collections import defaultdict


class BabyAI:
    """
    Phase 1: Rule-based classifier using learned patterns from corrections.
    Phase 2: Swap in the LoRA model by uncommenting the transformer code.
    """

    def __init__(self, config: dict):
        self.config = config
        self.model_path = config.get("ai", {}).get("baby_ai_model_path", "./ai/baby_ai/model.pt")
        self.training_data_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            "storage", "training_data.jsonl"
        )
        
        # Pattern memory: learned from corrections
        self.sender_patterns: dict[str, dict] = defaultdict(lambda: defaultdict(int))
        self.keyword_patterns: dict[str, dict] = defaultdict(lambda: defaultdict(int))
        self.ext_patterns: dict[str, dict] = defaultdict(lambda: defaultdict(int))
        
        self._load_patterns()
        
        # Phase 2 — uncomment when ready:
        # self._load_transformer_model()

    def _load_patterns(self):
        """Load learned patterns from training_data.jsonl."""
        if not os.path.exists(self.training_data_path):
            return
        
        with open(self.training_data_path) as f:
            for line in f:
                try:
                    example = json.loads(line.strip())
                    inp = example.get("input", {})
                    out = example.get("output", {})
                    category = out.get("category", "Other")
                    
                    # Learn sender → category association
                    sender = inp.get("sender", "").lower()
                    if sender:
                        domain = sender.split("@")[-1] if "@" in sender else sender
                        self.sender_patterns[domain][category] += 1
                    
                    # Learn keywords → category
                    text = f"{inp.get('subject', '')} {inp.get('snippet', '')} {inp.get('filename', '')}".lower()
                    for word in re.findall(r'\b\w{4,}\b', text):
                        self.keyword_patterns[word][category] += 1
                    
                    # Learn file extension → category
                    ext = inp.get("extension", "").lower()
                    if ext:
                        self.ext_patterns[ext][category] += 1
                        
                except (json.JSONDecodeError, KeyError):
                    continue

    def _predict_from_patterns(self, features: dict) -> tuple[str, float]:
        """
        Score each category using learned patterns.
        Returns (category, confidence 0-100).
        """
        scores: dict[str, float] = defaultdict(float)
        total_signals = 0

        # Sender domain signal (strong)
        sender = features.get("sender", "").lower()
        if sender and "@" in sender:
            domain = sender.split("@")[-1]
            if domain in self.sender_patterns:
                domain_votes = self.sender_patterns[domain]
                total = sum(domain_votes.values())
                for cat, count in domain_votes.items():
                    scores[cat] += (count / total) * 3.0  # Weight 3x
                total_signals += 3

        # Keyword signals
        text = f"{features.get('subject','')} {features.get('snippet','')} {features.get('filename','')}".lower()
        words = re.findall(r'\b\w{4,}\b', text)
        for word in words[:30]:  # Cap at 30 words
            if word in self.keyword_patterns:
                word_votes = self.keyword_patterns[word]
                total = sum(word_votes.values())
                for cat, count in word_votes.items():
                    scores[cat] += (count / total) * 1.0
                total_signals += 1

        # Extension signal (medium)
        ext = features.get("extension", "").lower()
        if ext and ext in self.ext_patterns:
            ext_votes = self.ext_patterns[ext]
            total = sum(ext_votes.values())
            for cat, count in ext_votes.items():
                scores[cat] += (count / total) * 2.0
            total_signals += 2

        if not scores:
            return "Other", 0.0

        # Pick winner and compute confidence
        best_cat = max(scores, key=scores.get)
        best_score = scores[best_cat]
        total_score = sum(scores.values())
        
        # Confidence: how dominant is the winner + how many signals we had
        raw_confidence = (best_score / total_score) * 100 if total_score > 0 else 0
        signal_penalty = max(0, 1 - (5 / max(total_signals, 1)))  # Penalize few signals
        confidence = raw_confidence * (0.5 + 0.5 * signal_penalty)
        
        return best_cat, min(confidence, 95.0)  # Never claim 100%

    def classify_email(self, email: dict) -> dict:
        features = {
            "sender": email.get("sender", ""),
            "subject": email.get("subject", ""),
            "snippet": email.get("snippet", ""),
        }
        category, confidence = self._predict_from_patterns(features)
        action = "move" if confidence > 60 else "archive"
        
        return {
            "category": category,
            "action": action,
            "suggested_label": category,
            "confidence": confidence,
            "reasoning": f"Baby AI: learned from {self._count_training_examples()} examples."
        }

    def classify_file(self, file: dict) -> dict:
        features = {
            "filename": file.get("name", ""),
            "extension": file.get("extension", ""),
        }
        category, confidence = self._predict_from_patterns(features)
        action = "move" if confidence > 60 else "skip"
        
        return {
            "category": category,
            "action": action,
            "new_name": None,
            "confidence": confidence,
            "reasoning": f"Baby AI: learned from {self._count_training_examples()} examples."
        }

    def _count_training_examples(self) -> int:
        if not os.path.exists(self.training_data_path):
            return 0
        with open(self.training_data_path) as f:
            return sum(1 for _ in f)

    # ── Phase 2: Uncomment to enable transformer model ──────────────────────
    # def _load_transformer_model(self):
    #     from transformers import AutoTokenizer, AutoModelForSequenceClassification
    #     from peft import PeftModel
    #     import torch
    #     
    #     base_model_name = "distilbert-base-uncased"
    #     self.tokenizer = AutoTokenizer.from_pretrained(base_model_name)
    #     base = AutoModelForSequenceClassification.from_pretrained(base_model_name)
    #     self.model = PeftModel.from_pretrained(base, self.model_path)
    #     self.model.eval()
    #     self.categories = ["Finances", "Work", "Personal", "Receipts",
    #                        "Travel", "Health", "Legal", "Newsletters", "Other"]
    #
    # def _transformer_predict(self, text: str) -> tuple[str, float]:
    #     import torch
    #     inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=128)
    #     with torch.no_grad():
    #         logits = self.model(**inputs).logits
    #         probs = torch.softmax(logits, dim=-1)[0]
    #     best_idx = probs.argmax().item()
    #     return self.categories[best_idx], float(probs[best_idx]) * 100
