"""
Baby AI Training Script — Phase 2
Fine-tunes a small classifier on your correction data using LoRA.

Run from project root:
    python ai/baby_ai/train.py

Requirements (install when ready):
    pip install torch transformers peft datasets scikit-learn unsloth

Uses Google Colab if running there — T4 GPU is free and sufficient.
"""

import json
import os
import sys
from pathlib import Path
from collections import Counter

TRAINING_DATA_PATH = Path(__file__).parent.parent.parent / "storage" / "training_data.jsonl"
MODEL_OUTPUT_PATH = Path(__file__).parent / "model.pt"

CATEGORIES = [
    "Finances", "Work", "Personal", "Receipts",
    "Travel", "Health", "Legal", "Newsletters", "Other"
]
CATEGORY_TO_ID = {cat: i for i, cat in enumerate(CATEGORIES)}
ID_TO_CATEGORY = {i: cat for cat, i in CATEGORY_TO_ID.items()}


def load_training_data():
    """Load and validate training examples."""
    examples = []
    with open(TRAINING_DATA_PATH) as f:
        for i, line in enumerate(f):
            try:
                ex = json.loads(line.strip())
                inp = ex.get("input", {})
                out = ex.get("output", {})
                category = out.get("category", "Other")
                
                if category not in CATEGORY_TO_ID:
                    category = "Other"
                
                # Build input text
                text = " ".join(filter(None, [
                    inp.get("subject", ""),
                    inp.get("sender", ""),
                    inp.get("snippet", "")[:200],
                    inp.get("filename", ""),
                ]))
                
                examples.append({
                    "text": text,
                    "label": CATEGORY_TO_ID[category],
                    "category": category
                })
            except (json.JSONDecodeError, KeyError) as e:
                print(f"Warning: skipping line {i}: {e}")
    
    return examples


def check_data_balance(examples):
    """Print class distribution to check for imbalance."""
    counts = Counter(ex["category"] for ex in examples)
    print("\n📊 Training data distribution:")
    for cat, count in sorted(counts.items(), key=lambda x: -x[1]):
        bar = "█" * min(count, 40)
        print(f"  {cat:15s} {bar} ({count})")
    
    min_count = min(counts.values())
    if min_count < 10:
        print(f"\n⚠️  Warning: Some categories have < 10 examples. Collect more corrections first.")
    print()


def train():
    """Main training function."""
    print("🤖 Baby AI Training Script")
    print("=" * 40)
    
    if not TRAINING_DATA_PATH.exists():
        print(f"❌ No training data found at {TRAINING_DATA_PATH}")
        print("   Use the widget and submit corrections first.")
        sys.exit(1)
    
    examples = load_training_data()
    print(f"✅ Loaded {len(examples)} training examples")
    
    if len(examples) < 50:
        print(f"⚠️  Only {len(examples)} examples. Recommend 200+ for good accuracy.")
        print("   Continue? (y/N)")
        if input().strip().lower() != "y":
            sys.exit(0)
    
    check_data_balance(examples)
    
    # ── Import ML libraries ──────────────────────────────────────────────────
    try:
        import torch
        from transformers import (
            AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
        )
        from peft import LoraConfig, get_peft_model, TaskType
        from datasets import Dataset
        from sklearn.model_selection import train_test_split
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("   Run: pip install torch transformers peft datasets scikit-learn")
        sys.exit(1)
    
    print("📦 Libraries loaded")
    
    # Split data
    train_data, eval_data = train_test_split(examples, test_size=0.15, random_state=42)
    train_dataset = Dataset.from_list(train_data)
    eval_dataset = Dataset.from_list(eval_data)
    
    # Tokenizer + base model
    MODEL_NAME = "distilbert-base-uncased"
    print(f"📥 Loading base model: {MODEL_NAME}")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_NAME, num_labels=len(CATEGORIES)
    )
    
    # Apply LoRA
    lora_config = LoraConfig(
        task_type=TaskType.SEQ_CLS,
        r=8,
        lora_alpha=16,
        lora_dropout=0.1,
        target_modules=["q_lin", "v_lin"]  # DistilBERT attention layers
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    # Tokenize
    def tokenize(batch):
        return tokenizer(batch["text"], truncation=True, max_length=128, padding="max_length")
    
    train_dataset = train_dataset.map(tokenize, batched=True)
    eval_dataset = eval_dataset.map(tokenize, batched=True)
    train_dataset = train_dataset.rename_column("label", "labels")
    eval_dataset = eval_dataset.rename_column("label", "labels")
    train_dataset.set_format("torch", columns=["input_ids", "attention_mask", "labels"])
    eval_dataset.set_format("torch", columns=["input_ids", "attention_mask", "labels"])
    
    # Training config
    training_args = TrainingArguments(
        output_dir=str(MODEL_OUTPUT_PATH.parent / "checkpoints"),
        num_train_epochs=5,
        per_device_train_batch_size=16,
        per_device_eval_batch_size=32,
        warmup_steps=50,
        weight_decay=0.01,
        evaluation_strategy="epoch",
        save_strategy="best",
        load_best_model_at_end=True,
        metric_for_best_model="accuracy",
        logging_steps=20,
        report_to="none"
    )
    
    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        import numpy as np
        preds = np.argmax(logits, axis=-1)
        accuracy = (preds == labels).mean()
        return {"accuracy": accuracy}
    
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        compute_metrics=compute_metrics
    )
    
    print("🏋️  Training started...")
    trainer.train()
    
    # Save
    model.save_pretrained(str(MODEL_OUTPUT_PATH.parent))
    tokenizer.save_pretrained(str(MODEL_OUTPUT_PATH.parent))
    print(f"✅ Model saved to {MODEL_OUTPUT_PATH.parent}")
    
    # Update config
    config_path = TRAINING_DATA_PATH.parent.parent / "config.json"
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
        config["ai"]["baby_ai_enabled"] = True
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        print("✅ Baby AI enabled in config.json")
    
    print("\n🎉 Training complete! Restart the app to use Baby AI.")


if __name__ == "__main__":
    train()
