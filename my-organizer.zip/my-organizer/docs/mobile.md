# Mobile App Guide

The FastAPI backend (`api/server.py`) is designed to work with any frontend — desktop (Electron), mobile (React Native), or web (browser).

## Option A: React Native (Recommended)

The cleanest path to a native iOS + Android app.

### Setup

```bash
npx create-expo-app my-organizer-mobile
cd my-organizer-mobile
npm install axios @react-navigation/native
```

### Point to your backend

```javascript
// config.js
export const API_URL = 'http://YOUR_IP:5000';
// Use your local IP when on same WiFi
// Use a VPS IP or ngrok for remote access
```

### Reuse the same API

All the endpoints work the same. The mobile app just calls:
- `GET /actions` — show activity
- `POST /corrections` — submit corrections (great on mobile!)
- `GET /stats` — stats dashboard
- `POST /emails/organize-all` — trigger organization

### Expose your backend (for mobile testing)

```bash
# Option 1: ngrok (easiest)
ngrok http 5000

# Option 2: Tailscale (private network, no port forwarding)
# Install Tailscale, then use your device's Tailscale IP

# Option 3: VPS (DigitalOcean $4/mo droplet)
# Deploy api/server.py with systemd
```

---

## Option B: Capacitor (Web → Mobile)

If you want to reuse the existing HTML/JS widget as a mobile app.

```bash
npm install @capacitor/core @capacitor/cli
npx cap init "My Organizer" "com.yourname.myorganizer"
npx cap add ios
npx cap add android
```

The existing `electron/index.html` and `renderer.js` work as-is in Capacitor. Just change the API URL to your backend address.

---

## Option C: Progressive Web App (PWA)

The simplest option — works on any device via browser.

1. Host the `electron/index.html` + `renderer.js` as a static site
2. Add a `manifest.json` and service worker
3. Access from any phone browser and "Add to Home Screen"

---

## Recommended Architecture

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   Desktop   │    │   Mobile    │    │    Web      │
│  (Electron) │    │(React Native│    │   (PWA)     │
└──────┬──────┘    └──────┬──────┘    └──────┬──────┘
       │                  │                  │
       └──────────────────┼──────────────────┘
                          ↓
              ┌───────────────────────┐
              │   FastAPI Backend     │
              │   api/server.py       │
              │   (shared by all)     │
              └───────────┬───────────┘
                          ↓
              ┌───────────────────────┐
              │  AI + SQLite + IMAP   │
              └───────────────────────┘
```

One backend. Multiple frontends. All the same API.
