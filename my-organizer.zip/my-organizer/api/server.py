"""
My Organizer — FastAPI Backend
Serves the Electron frontend and handles AI orchestration.
Also works standalone for the mobile app (React Native).
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List
import asyncio
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai.orchestrator import Orchestrator
from helpers.email_utils import EmailManager
from helpers.file_utils import FileManager
from storage.database import Database

app = FastAPI(title="My Organizer API", version="1.0.0")

# Allow Electron renderer and React Native dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load config
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
with open(CONFIG_PATH) as f:
    config = json.load(f)

db = Database()
orchestrator = Orchestrator(config, db)
email_mgr = EmailManager(config)
file_mgr = FileManager(config)


# ─── Models ──────────────────────────────────────────────────────────────────

class EmailItem(BaseModel):
    uid: str
    subject: str
    sender: str
    snippet: str
    date: str

class FileItem(BaseModel):
    path: str
    name: str
    extension: str
    size_bytes: int

class CorrectionRequest(BaseModel):
    action_id: int
    correct_category: str
    correct_action: str  # "move" | "archive" | "delete" | "label"
    notes: Optional[str] = None

class ManualOrganizeRequest(BaseModel):
    item_type: str  # "email" | "file"
    item_id: str
    category: str


# ─── Health ──────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0", "baby_ai": orchestrator.baby_ai_enabled}


# ─── Actions & History ───────────────────────────────────────────────────────

@app.get("/actions")
async def get_actions(limit: int = 50, offset: int = 0):
    """Return recent actions for the activity log."""
    actions = db.get_actions(limit=limit, offset=offset)
    return {"actions": actions, "total": db.count_actions()}

@app.get("/actions/{action_id}")
async def get_action(action_id: int):
    action = db.get_action(action_id)
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")
    return action

@app.post("/actions/{action_id}/undo")
async def undo_action(action_id: int):
    """Undo a recent action within the undo window."""
    action = db.get_action(action_id)
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")
    
    try:
        if action["item_type"] == "email":
            await email_mgr.undo_action(action)
        else:
            await file_mgr.undo_action(action)
        db.mark_undone(action_id)
        return {"success": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/actions/{action_id}/why")
async def explain_action(action_id: int):
    """Return AI explanation for why this decision was made."""
    action = db.get_action(action_id)
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")
    explanation = orchestrator.explain_decision(action)
    return {"explanation": explanation, "action": action}


# ─── Corrections (Training Data) ─────────────────────────────────────────────

@app.post("/corrections")
async def submit_correction(req: CorrectionRequest):
    """User corrects an AI decision → logged as training data."""
    action = db.get_action(req.action_id)
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")
    
    db.log_correction(
        action_id=req.action_id,
        correct_category=req.correct_category,
        correct_action=req.correct_action,
        notes=req.notes
    )
    
    # Also export to training_data.jsonl for Baby AI
    orchestrator.add_training_example(action, req.correct_category, req.correct_action)
    
    correction_count = db.count_corrections()
    message = "Correction saved."
    if correction_count in [50, 100, 200, 500]:
        message += f" You now have {correction_count} corrections — consider re-training Baby AI!"
    
    return {"success": True, "correction_count": correction_count, "message": message}

@app.get("/corrections/stats")
async def correction_stats():
    return db.get_correction_stats()


# ─── Emails ──────────────────────────────────────────────────────────────────

@app.get("/emails/inbox")
async def get_inbox(limit: int = 20):
    """Fetch recent inbox emails."""
    try:
        emails = await email_mgr.fetch_inbox(limit=limit)
        return {"emails": emails}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/emails/organize")
async def organize_email(item: EmailItem, background_tasks: BackgroundTasks):
    """Trigger AI organization for a specific email."""
    background_tasks.add_task(_organize_email_task, item)
    return {"message": "Organization queued", "uid": item.uid}

async def _organize_email_task(item: EmailItem):
    result = await orchestrator.decide_email(item.dict())
    if result["confidence"] >= config["ai"]["confidence_threshold_auto"]:
        await email_mgr.execute_action(item.uid, result)
    db.log_action(item_type="email", item_id=item.uid, decision=result)

@app.post("/emails/organize-all")
async def organize_all_emails(background_tasks: BackgroundTasks):
    """Fetch and organize all unprocessed inbox emails."""
    background_tasks.add_task(_organize_all_emails_task)
    return {"message": "Bulk organization started"}

async def _organize_all_emails_task():
    emails = await email_mgr.fetch_inbox(limit=50)
    for email in emails:
        result = await orchestrator.decide_email(email)
        if result["confidence"] >= config["ai"]["confidence_threshold_auto"]:
            await email_mgr.execute_action(email["uid"], result)
        db.log_action(item_type="email", item_id=email["uid"], decision=result)


# ─── Files ───────────────────────────────────────────────────────────────────

@app.get("/files/watched")
async def get_watched_files():
    """List files currently in watched folders."""
    files = file_mgr.scan_watched_folders()
    return {"files": files}

@app.post("/files/organize")
async def organize_file(item: FileItem, background_tasks: BackgroundTasks):
    """Trigger AI organization for a specific file."""
    background_tasks.add_task(_organize_file_task, item)
    return {"message": "Organization queued", "path": item.path}

async def _organize_file_task(item: FileItem):
    result = await orchestrator.decide_file(item.dict())
    if result["confidence"] >= config["ai"]["confidence_threshold_auto"]:
        file_mgr.execute_action(item.path, result)
    db.log_action(item_type="file", item_id=item.path, decision=result)

@app.post("/files/organize-all")
async def organize_all_files(background_tasks: BackgroundTasks):
    """Organize all files in watched folders."""
    background_tasks.add_task(_organize_all_files_task)
    return {"message": "Bulk file organization started"}

async def _organize_all_files_task():
    files = file_mgr.scan_watched_folders()
    for file in files:
        result = await orchestrator.decide_file(file)
        if result["confidence"] >= config["ai"]["confidence_threshold_auto"]:
            file_mgr.execute_action(file["path"], result)
        db.log_action(item_type="file", item_id=file["path"], decision=result)


# ─── Stats ───────────────────────────────────────────────────────────────────

@app.get("/stats")
async def get_stats():
    return {
        "total_organized": db.count_actions(),
        "total_corrections": db.count_corrections(),
        "baby_ai_accuracy": db.get_baby_ai_accuracy(),
        "free_api_calls_today": db.count_api_calls_today(),
        "model_used_breakdown": db.get_model_breakdown(),
        "top_categories": db.get_top_categories()
    }


# ─── Config ──────────────────────────────────────────────────────────────────

@app.get("/config")
async def get_config():
    """Return safe (no secrets) config for the UI."""
    safe = {k: v for k, v in config.items() if k not in ("gemini_api_key",)}
    safe["imap"] = {k: v for k, v in config.get("imap", {}).items() if k != "password"}
    return safe

@app.post("/config")
async def update_config(updates: dict):
    config.update(updates)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)
    return {"success": True}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=5000)
